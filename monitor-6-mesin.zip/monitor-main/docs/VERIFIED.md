# Status verifikasi

Penanda: **TERVERIFIKASI** (dilihat langsung), **ASUMSI** (belum dibuktikan; sistem melaporkan kegagalan secara eksplisit, tidak menebak), **BELUM**.
Pemeriksaan dilakukan 2026-10-21 dengan membuka halaman utama tiap situs dari lingkungan pengembangan yang **tidak punya akses jaringan bebas**:
hanya halaman utama yang bisa dibuka, bukan `/data/*.json`, dan tidak ada run pengumpul nyata.

## Situs mesin

| Mesin | Halaman utama | Jalur data | Catatan |
|---|---|---|---|
| `tnv2` | TERVERIFIKASI terbuka. Judul "Asgra TN machine"; bagian Gerbang BTC, Sinyal, Pantauan 40 koin, Jurnal, Strategi. Tabel diisi JS ("Memuat jurnal…"). | `/data/journal.json`: **ASUMSI** | Memuat banner "belum lulus forward test (150 trade, 20 minggu)". |
| `gemini` | TERVERIFIKASI terbuka. Struktur sama dengan `tnv2`. | **ASUMSI** | Tanpa banner peringatan. |
| `deepseek` | TERVERIFIKASI terbuka. "Mesin 2 Pro", struktur sama; "Jurnal Sinyal" dan filter min. 2 konfirmasi. | **ASUMSI** | |
| `grok` | TERVERIFIKASI terbuka, tetapi layout **berbeda** ("ASGRA Desk"); tidak ada tabel jurnal pada teks halaman. Menyebut jurnal 14–16 Okt dan forward test "35/150 trade". | **BELUM** | Kemungkinan memakai JSON yang sama; bila tidak, perlu Discover. |
| `chatgpt` | **BELUM**: permintaan saya mengembalikan *client error*. | **BELUM** | Bisa 404, proteksi deployment, atau pemblokiran pembaca saya. Tidak bisa dibedakan dari sini. |
| `meta` | **BELUM**: sama dengan `chatgpt`. | **BELUM** | |

Dasar asumsi `/data/journal.json`: pada proyek asal, halaman Mesin 2 (`/tn/`) memuat `data/journal.json` (terbukti di log jaringan
discovery lama, HTTP 200) dengan field `id, waktu, t, aset, arah, entry, sl, tp, alasan, hasil, R, h`. Situs Vercel ini bergaya sama
(judul, seksi, "Jurnal"), tetapi belum dibuktikan memakai jalur yang sama.

## Kode

| Item | Status | Bukti |
|---|---|---|
| Ekstraktor tabel Jurnal (`src/parsers/journal-dom.js`) | TERVERIFIKASI di Chromium sungguhan | Tabel dirender JS setelah jeda: placeholder → `found:false`, setelah render → baris terbaca benar. Header yang dipakai berasal dari discovery lama `/tn/`, bukan dari situs Vercel. |
| Pengumpul JSON (retry, 404 tidak diulang, HTML ≠ JSON, fallback DOM) | TERVERIFIKASI dengan fetch palsu | `test/journal-scraper.test.js` |
| Statistik 6 mesin (peringkat, pasangan, kesepakatan, ekuitas) | TERVERIFIKASI dengan data sintetis | `test/multi-engine.test.js`, `test/stats.test.js` |
| Dashboard | TERVERIFIKASI dengan data sintetis di Chromium (lebar HP), tanpa error JS | Data sintetis tidak disertakan. |
| `test/journal-dom.test.js`, `test/pipeline.test.js`, `test/parse-normalize.test.js` | **BELUM dijalankan** di lingkungan pengembangan | Butuh `linkedom` (`npm ci`); dijalankan otomatis oleh workflow sebelum koleksi. |
| Playwright `scrapeJournalDom` end-to-end pada situs nyata | **BELUM** | Tes pertama: workflow Collect. |
| Binance klines dari runner | TERVERIFIKASI pada proyek asal (HTTP 200) | Belum diuji ulang di proyek ini. |

## Pertanyaan terbuka
- Apakah tiap mesin punya jurnal **sendiri**, atau beberapa membaca jurnal yang sama? Bila identik, perbandingan tidak bermakna. Cek matriks kesepakatan setelah beberapa run.
- Arti `bm`/`bi` dan `hasil: "tidak terisi"` pada jurnal belum diketahui; disimpan utuh di `rawData`, tidak dipakai.
