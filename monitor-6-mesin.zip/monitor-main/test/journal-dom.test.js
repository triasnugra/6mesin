import test from 'node:test';
import assert from 'node:assert/strict';
import { parseHTML } from 'linkedom';
import { extractJournalTable } from '../src/parsers/journal-dom.js';
import { parseJournalEntry } from '../src/parsers/tn.js';

const page = (inner) => parseHTML(`<html><body>${inner}</body></html>`).document;
const JOURNAL = `<div class="sc"><table><thead><tr><th>waktu</th><th>aset</th><th>arah</th><th>entry</th><th>sl</th><th>tp</th><th>hasil</th><th>R</th><th>alasan</th></tr></thead><tbody>
<tr><td>2026-10-04 06:47 UTC</td><td>LINK</td><td>SHORT</td><td>14.017</td><td>15.856</td><td>10.339</td><td>kedaluwarsa</td><td>0.61</td><td>deviasi atas gagal bertahan</td></tr>
<tr><td>2026-10-04 06:47 UTC</td><td>ICP</td><td>LONG</td><td>3.393</td><td>3.0338</td><td>4.1115</td><td>SL</td><td>-1</td><td>breakout ber-close</td></tr>
<tr><td>2026-10-20 05:04 UTC</td><td>ZRO</td><td>SHORT</td><td>2.253</td><td>2.3206</td><td>2.1178</td><td>menunggu</td><td></td><td>Double Deviation</td></tr></tbody></table></div>`;

test('membaca tabel Jurnal: kolom dikenali dari header, angka diparse, R kosong dipertahankan', () => {
  const r = extractJournalTable(page(`<table><tr><th>x</th></tr><tr><td>1</td></tr></table>${JOURNAL}`));
  assert.equal(r.meta.found, true); assert.equal(r.items.length, 3);
  assert.deepEqual(r.items[0], { waktu: '2026-10-04 06:47 UTC', aset: 'LINK', arah: 'SHORT', entry: 14.017, sl: 15.856, tp: 10.339, hasil: 'kedaluwarsa', R: 0.61, alasan: 'deviasi atas gagal bertahan' });
  assert.equal(r.items[1].R, -1); assert.equal(r.items[2].R, '');
});
test('placeholder "Memuat jurnal…" atau tanpa tabel -> found:false (bukan "0 setup")', () => {
  assert.equal(extractJournalTable(page('<table><tr><td>Memuat jurnal…</td></tr></table>')).meta.found, false);
  assert.equal(extractJournalTable(page('<p>hi</p>')).meta.found, false);
});
test('kolom tambahan / urutan berbeda tidak merusak pemetaan', () => {
  const r = extractJournalTable(page('<table><tr><th>aset</th><th>extra</th><th>arah</th><th>entry</th><th>sl</th><th>tp</th></tr><tr><td>BTC</td><td>zz</td><td>LONG</td><td>80,000.5</td><td>78000</td><td>85000</td></tr></table>'));
  assert.deepEqual([r.items[0].aset, r.items[0].arah, r.items[0].entry, r.items[0].sl], ['BTC', 'LONG', 80000.5, 78000]);
});
test('record dari baris DOM (tanpa h/t) memakai waktu sumber & idKey sama dengan JSON tanpa h', () => {
  const dom = extractJournalTable(page(JOURNAL)).items[1];
  const p = parseJournalEntry(dom, 'gemini');
  assert.equal(p.analysisTimeMs, Date.UTC(2026, 9, 4, 6, 47)); assert.equal(p.engine, 'gemini');
  const json = parseJournalEntry({ waktu: '2026-10-04 06:47 UTC', aset: 'ICP', arah: 'LONG', entry: 3.393, sl: 3.0338, tp: 4.1115 }, 'gemini');
  assert.equal(p.idKey, json.idKey);
});
