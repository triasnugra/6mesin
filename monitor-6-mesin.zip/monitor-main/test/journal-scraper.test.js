import test from 'node:test';
import assert from 'node:assert/strict';
import { scrapeJournalSite, unwrapJournal, journalUrls } from '../src/scrapers/journal.js';

const cfg = { url: 'https://x.example/', retries: 3, retryBaseMs: 1, forwardReportPath: '/data/forward-report.json' };
const entry = { aset: 'SUI', arah: 'SHORT', entry: 1.14, sl: 1.2, tp: 1.03, waktu: '2026-10-08 01:47 UTC', t: 1791424020000, h: 'abc' };
const resp = (status, body, type = 'application/json') => ({ ok: status >= 200 && status < 300, status, text: async () => (typeof body === 'string' ? body : JSON.stringify(body)), headers: { get: () => type } });
const mkFetch = (routes) => { const calls = []; const f = async (url) => { calls.push(url.split('?')[0]); const k = Object.keys(routes).find((r) => url.includes(r)); return k ? routes[k]() : resp(404, 'nope', 'text/html'); }; f.calls = calls; return f; };

test('journalUrls: default /data/journal.json; journalUrl/journalUrls menimpa', () => {
  assert.deepEqual(journalUrls({ url: 'https://a.b/' }), ['https://a.b/data/journal.json']);
  assert.deepEqual(journalUrls({ url: 'https://a.b', journalUrl: 'https://c.d/j.json' }), ['https://c.d/j.json']);
});
test('unwrapJournal: array atau objek pembungkus; selain itu null', () => {
  assert.deepEqual(unwrapJournal([1]), [1]); assert.deepEqual(unwrapJournal({ journal: [2] }), [2]);
  assert.equal(unwrapJournal({ foo: 1 }), null); assert.equal(unwrapJournal('x'), null);
});
test('JSON array terbaca -> OK, sumber & forward-report tercatat', async () => {
  const f = mkFetch({ 'journal.json': () => resp(200, [entry]), 'forward-report.json': () => resp(200, { ready: false, locked: true, counts: { selesai: 3 } }) });
  const r = await scrapeJournalSite(cfg, { fetchImpl: f });
  assert.equal(r.status, 'OK'); assert.equal(r.items.length, 1);
  assert.equal(r.diagnostics.source, 'https://x.example/data/journal.json');
  assert.equal(r.diagnostics.forward.locked, true);
});
test('array kosong -> OK_NO_SETUPS; forward-report gagal hanya warning', async () => {
  const r = await scrapeJournalSite(cfg, { fetchImpl: mkFetch({ 'journal.json': () => resp(200, []) }) });
  assert.equal(r.status, 'OK_NO_SETUPS'); assert.ok(r.diagnostics.warnings.some((w) => w.startsWith('FORWARD_REPORT_UNAVAILABLE')));
});
test('HTTP 404 bersifat tetap: tidak diulang, status FAILED, galat tercatat', async () => {
  const f = mkFetch({});
  const r = await scrapeJournalSite(cfg, { fetchImpl: f });
  assert.equal(r.status, 'FAILED'); assert.equal(f.calls.length, 1);
  assert.ok(r.diagnostics.errors[0].includes('HTTP_404')); assert.equal(r.diagnostics.httpStatus, 404);
});
test('HTTP 503 diulang sesuai retries', async () => {
  const f = mkFetch({ 'journal.json': () => resp(503, 'x', 'text/plain') });
  const r = await scrapeJournalSite({ ...cfg, retries: 2 }, { fetchImpl: f });
  assert.equal(r.status, 'FAILED'); assert.equal(f.calls.length, 2);
});
test('200 berisi HTML (SPA fallback) = NOT_JSON, bukan "tidak ada setup"', async () => {
  const r = await scrapeJournalSite(cfg, { fetchImpl: mkFetch({ 'journal.json': () => resp(200, '<html></html>', 'text/html') }) });
  assert.equal(r.status, 'FAILED'); assert.ok(r.diagnostics.errors[0].includes('NOT_JSON'));
});
test('JSON gagal -> pakai tabel DOM; hasil OK, galat JSON turun jadi warning', async () => {
  const domScrape = async () => ({ status: 'OK', items: [entry], diagnostics: { errors: [], warnings: [], meta: { found: true } } });
  const r = await scrapeJournalSite(cfg, { fetchImpl: mkFetch({}), domScrape });
  assert.equal(r.status, 'OK'); assert.equal(r.items.length, 1); assert.deepEqual(r.diagnostics.errors, []);
  assert.ok(r.diagnostics.warnings.includes('JSON_UNAVAILABLE_USING_DOM_TABLE'));
  assert.ok(r.diagnostics.warnings.some((w) => w.includes('HTTP_404')));
});
test('domFallback:false tidak memanggil browser; DOM juga gagal -> FAILED dengan kedua galat', async () => {
  let called = 0;
  const dom = async () => { called++; return { status: 'FAILED', items: [], diagnostics: { errors: ['DOM_HTTP_401'], warnings: [] } }; };
  const a = await scrapeJournalSite({ ...cfg, domFallback: false }, { fetchImpl: mkFetch({}), domScrape: dom });
  assert.equal(called, 0); assert.equal(a.status, 'FAILED');
  const b = await scrapeJournalSite(cfg, { fetchImpl: mkFetch({}), domScrape: dom });
  assert.equal(called, 1); assert.equal(b.status, 'FAILED'); assert.ok(b.diagnostics.errors.some((e) => e.includes('DOM_HTTP_401')) && b.diagnostics.errors.some((e) => e.includes('HTTP_404')));
});
