import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { buildDashboard } from '../src/aggregate.js';

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'bench-multi-'));
process.env.DATA_DIR = path.join(tmp, 'data');
// Semua modul yang membaca DATA_DIR harus dimuat dinamis SETELAH env di-set (import statis dievaluasi lebih dulu).
const { collect, build, resolveSources } = await import('../src/index.js');
const store = await import('../src/storage/store.js');

const cfg = { minSamplePerEngine: 30, bootstrapIterations: 300, pairWindowMinutes: 120, cluster: { windowHours: 24, entryTolerance: 0.01 }, cancelPatterns: [], rawRetentionPerEngine: 3 };
let n = 0;
const mk = (engine, result, r, over = {}) => ({ setupId: `${engine}-${n++}`, engine, symbol: `C${n}USDT`, ticker: `C${n}`, direction: 'LONG', entryPrice: 100 + n, takeProfit: [120], stopLoss: 90,
  analysisTimeUtc: '2026-10-08T01:47:00.000Z', analysisTimeSource: 'source', warnings: [],
  evaluation: { result, rMultiple: r, entryTimeUtc: '2026-10-08T02:00:00.000Z', resultTimeUtc: `2026-10-0${8 + (n % 2)}T05:00:00.000Z` }, ...over });
const gen = (engine, count, winEvery) => Array.from({ length: count }, (_, i) => (i % winEvery === 0 ? mk(engine, 'TP', 2) : mk(engine, 'SL', -1)));

test('dashboard 3 mesin: peringkat menurut expectancy, pasangan signifikan, eligible mengikuti minimum sampel', () => {
  const setups = [...gen('a', 60, 2), ...gen('b', 60, 6), ...gen('c', 10, 2)];
  const d = buildDashboard({ setups, diagnostics: { runs: [] }, cfg, nowIso: '2026-10-21T00:00:00Z', engineList: [{ id: 'a', label: 'A' }, { id: 'b', label: 'B' }, { id: 'c', label: 'C' }] });
  const lb = d.leaderboard.all;
  assert.deepEqual(lb.map((x) => x.id), ['a', 'c', 'b']);                         // a: +0.5, c: +0.5 (n kecil), b: -0.5 -> urut menurun; a/c seri tidak diuji
  assert.equal(lb.find((x) => x.id === 'c').eligible, false);
  assert.equal(lb.find((x) => x.id === 'a').eligible, true);
  const ab = d.comparison.all.pairwise.find((p) => p.a === 'a' && p.b === 'b');
  assert.equal(ab.verdict, 'A_BETTER');
  assert.equal(d.comparison.all.pairwise.find((p) => p.a === 'a' && p.b === 'c').verdict, 'INSUFFICIENT_SAMPLE');
  assert.equal(d.comparison.all.pairwise.length, 3);
  assert.equal(lb.find((x) => x.id === 'a').significantWins, 1); assert.equal(lb.find((x) => x.id === 'b').significantLosses, 1);
  assert.equal(d.equity.all.a.length, 60);
  assert.ok(d.agreement.matrix.length === 3);
});
test('engineList kosong diturunkan dari setup; tanpa setup tidak error', () => {
  assert.deepEqual(buildDashboard({ setups: [mk('z', 'TP', 2)], diagnostics: { runs: [] }, cfg, nowIso: 'x' }).engineList.map((e) => e.id), ['z']);
  const e = buildDashboard({ setups: [], diagnostics: { runs: [] }, cfg, nowIso: '2026-10-21T00:00:00Z', engineList: [{ id: 'a', label: 'A' }] });
  assert.equal(e.leaderboard.all[0].resolved, 0); assert.equal(e.comparison.all.pairwise.length, 0);
});
test('resolveSources: default digabung, kunci _catatan dibuang', () => {
  const s = resolveSources({ _note: 'x', a: { url: 'https://a' }, b: { url: 'https://b', retries: 1 } }, { retries: 3, domFallback: true });
  assert.deepEqual(Object.keys(s), ['a', 'b']); assert.equal(s.a.retries, 3); assert.equal(s.b.retries, 1); assert.equal(s.a.domFallback, true);
});
test('collect 6 mesin: id unik per mesin walau jurnal identik; satu mesin gagal tidak mengganggu yang lain', async () => {
  const journal = JSON.parse(fs.readFileSync(new URL('./fixtures/tn-journal-sample.json', import.meta.url), 'utf8'));
  const names = ['tnv2', 'gemini', 'chatgpt', 'grok', 'deepseek', 'meta'];
  const sources = Object.fromEntries(names.map((k) => [k, { url: `https://${k}.example` }]));
  const scrapeEngine = async (engine) => (engine === 'meta'
    ? { status: 'FAILED', items: [], diagnostics: { errors: ['JSON x: HTTP_401'], warnings: [], httpStatus: 401, durationMs: 1 } }
    : { status: 'OK', items: journal.map((j) => ({ ...j })), diagnostics: { errors: [], warnings: [], httpStatus: 200, durationMs: 1 } });
  const meta = { trackingStartedUtc: {} };
  const rep = await collect({ sources, settings: cfg, now: Date.parse('2026-10-16T06:00:00Z'), scrapeEngine, meta });
  assert.deepEqual(Object.keys(rep), names);
  for (const k of names.filter((x) => x !== 'meta')) assert.equal(rep[k].added, journal.length);
  assert.equal(rep.meta.emptyKind, 'FETCH_FAILED'); assert.equal(rep.meta.added, 0);
  const setups = store.loadSetups();
  assert.equal(new Set(setups.map((s) => s.setupId)).size, journal.length * 5);
  assert.deepEqual([...new Set(setups.map((s) => s.engine))].sort(), names.filter((x) => x !== 'meta').sort());
  assert.ok(setups.every((s) => s.analysisTimeSource === 'source'));
  const dash = build({ settings: cfg, sources, siteDataDir: path.join(tmp, 'site') });
  assert.deepEqual(dash.engineList.map((e) => e.id), names);                      // mesin gagal tetap muncul di dashboard
  assert.equal(dash.leaderboard.all.find((x) => x.id === 'meta').published, 0);
});
