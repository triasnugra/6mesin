# Monitor 6 Mesin Analisis Crypto

Merekam setiap setup dari **6 mesin** (situs Vercel), mengevaluasinya terhadap candle Binance (TP / SL / dll.), lalu
membandingkan kinerjanya di satu dashboard. Hasil bersifat **teoretis berbasis candle**, bukan trading nyata.

| Id | Situs |
|---|---|
| `tnv2` | https://tnv2.vercel.app |
| `gemini` | https://gemini-mesin.vercel.app |
| `chatgpt` | https://chatgpt-mesin.vercel.app |
| `grok` | https://grok-mesin.vercel.app |
| `deepseek` | https://deepseek-mesin.vercel.app |
| `meta` | https://meta-mesin.vercel.app |

Menambah/mengganti mesin: edit satu entri di `config/sources.json`. Dashboard menyesuaikan jumlah mesin otomatis.
**Status verifikasi tiap situs ada di `docs/VERIFIED.md`. Baca dulu sebelum mempercayai angkanya.**

## Dashboard
Overview (kesehatan pengumpulan per mesin, peringkat, kurva R kumulatif) · Live Setups · Historical Results ·
Engine Comparison (matriks selisih expectancy 6×6 + signifikansi, per arah, per hari, kesepakatan/konflik antar-mesin) ·
Ticker Analysis · Diagnostics · Data Quality.

## Cara data diambil (per mesin)
1. **JSON publik** `<situs>/data/journal.json` (konvensi mesin Asgra; sama dengan mesin /tn/ pada proyek asal). Tanpa browser.
2. **Cadangan:** bila JSON gagal (404, bukan JSON, dll.), tabel *Jurnal* di halaman dibaca lewat Playwright. Kolom dikenali
   dari teks header (`waktu, aset, arah, entry, sl, tp, hasil, R, alasan`).
3. Bila keduanya gagal, mesin ditandai `FAILED` dengan penyebabnya di Diagnostics. **Gagal baca ≠ tidak ada setup**, dan
   mesin lain tetap diproses.

Jalur data lain bisa diatur per mesin di `config/sources.json`: `journalUrl`, `journalUrls`, atau `"domFallback": false`.

## Setup (cukup lewat web GitHub)
1. Unggah isi proyek ke repo (termasuk `.github/`).
2. **Settings → Pages → Source: GitHub Actions.** **Settings → Actions → General → Workflow permissions: Read and write.**
3. **Actions → "Collect, evaluate, deploy" → Run workflow.** Jalan terjadwal ±30 menit (best-effort).
4. Dashboard: `https://<user>.github.io/<repo>/`.

**Alternatif hosting di Vercel:** import repo yang sama di Vercel (`vercel.json` sudah menunjuk ke folder `site`, tanpa build).
Workflow tetap yang mengumpulkan data dan meng-commit `data/` + `site/data/`; tiap commit memicu deploy Vercel.

## Aturan utama (diwarisi dari proyek asal)
- **Status final:** `TP`, `SL`, `CANCELLED`, `EXPIRED`, `INVALID`, `AMBIGUOUS`. `PENDING` untuk yang masih aktif.
- **Hasil sumber disimpan terpisah** (`sourceResult`); ketidaksesuaian TP/SL sumber vs evaluasi kita tampil di Data Quality.
- **Waktu analisis** dari sumber (`t` / `waktu`). Bila tidak ada, dipakai waktu scan pertama (`first_seen`), atau
  `unknown_before_tracking` (tidak dievaluasi) pada putaran pertama.
- **ID setup = id mesin + hash `h` jurnal** (atau gabungan waktu/aset/arah/level bila `h` tidak ada). Setup yang sama di dua mesin
  tetap dua record terpisah. Setup baru tidak menimpa histori.
- **TP tercapai sebelum entry tersentuh** → `EXPIRED`. **TP dan SL di candle yang sama** → dipertajam dengan candle 1m; masih ambigu → `AMBIGUOUS`.
- **Perbandingan berpasangan** (15 pasang dari 6 mesin): bootstrap CI95 selisih expectancy; "unggul" hanya bila kedua mesin
  punya ≥30 setup selesai (TP/SL) dan CI tidak mencakup 0. Dengan 15 perbandingan sekaligus, satu-dua hasil "signifikan"
  bisa muncul karena kebetulan; baca sebagai indikasi, bukan bukti.
- Sampel independen: satu setup per klaster near-duplicate (mesin + simbol + arah, ≤24 jam, entry ±1%).

## Asumsi & keterbatasan
- Fill limit dianggap terjadi saat harga menyentuh level. Tanpa fee, funding, dan slippage.
- R = |TP−fill| / |fill−SL| untuk TP; −1 untuk SL. Hanya TP pertama yang dievaluasi.
- TTL entry 72 jam dan batas hold 30 hari (`config/settings.json`); aturan sama untuk semua mesin.
- Mesin yang berbagi logika dasar (mis. aturan "Eliz") bisa menerbitkan setup yang sangat mirip, jadi sampel antar-mesin
  tidak sepenuhnya independen. Lihat matriks kesepakatan di Engine Comparison.
- Data proyek asal (Mesin 1 `/crypto/` dan Mesin 2 `/tn/` milik triasnugra) **tidak dibawa**; pelacakan dimulai dari nol.

## Troubleshooting
| Gejala | Penyebab / tindakan |
|---|---|
| `HTTP_401` / `HTTP_403` pada satu mesin | Deployment Vercel mesin itu dilindungi (Deployment Protection) atau memblokir bot. Matikan proteksi untuk produksi, atau beri jalur data publik. |
| `HTTP_404` pada `/data/journal.json` | Mesin tidak memakai jalur itu. Jalankan workflow **Discover** untuk mesin tsb (lihat `network.json`), lalu isi `journalUrl` di `config/sources.json`. |
| `NOT_JSON` | Situs menjawab 200 dengan HTML (SPA fallback). Sama seperti di atas. |
| `DOM_JOURNAL_TABLE_NOT_FOUND` | Tabel Jurnal tidak ada / headernya berbeda (mis. layout "ASGRA Desk" milik `grok`). Jalankan Discover dan sesuaikan `src/parsers/journal-dom.js`. |
| `JSON_UNAVAILABLE_USING_DOM_TABLE` (warning) | JSON gagal tetapi tabel di halaman terbaca. Data tetap masuk. |
| `priceDataError` (HTTP 451/403) | Binance memblokir runner. Ubah `binanceBaseUrls` di settings. |
| Push gagal | Concurrency dan retry sudah ada. Pastikan izin *Read and write*. |

## Menjalankan lokal
`npm ci && npm test`. Koleksi nyata: `npx playwright install chromium && node src/index.js all` (opsi `--only=tnv2,grok`).
