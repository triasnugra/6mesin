// Pengumpul generik untuk mesin berformat jurnal Asgra. Urutan: (1) JSON publik, (2) tabel Jurnal di halaman lewat browser.
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const KEYS = ['journal', 'entries', 'data', 'items', 'setups'];

/** Terima array langsung, atau objek pembungkus ({journal:[...]} dst.). Selain itu null (tidak menebak). */
export function unwrapJournal(j) {
  if (Array.isArray(j)) return j;
  if (j && typeof j === 'object') return KEYS.map((k) => j[k]).find(Array.isArray) ?? null;
  return null;
}

/** Galat 4xx dan bukan-JSON bersifat tetap (tidak diulang); jaringan/5xx diulang dengan jeda eksponensial. */
async function getJson(url, cfg, fetchImpl) {
  let last;
  for (let i = 0; i < (cfg.retries ?? 3); i++) {
    try {
      const sep = url.includes('?') ? '&' : '?';
      const res = await fetchImpl(`${url}${sep}_=${Date.now()}`, {
        signal: AbortSignal.timeout(cfg.fetchTimeoutMs ?? 30000), headers: { 'cache-control': 'no-cache' },
      });
      if (res.ok) {
        const text = await res.text();
        try { return { json: JSON.parse(text), status: res.status }; }
        catch { throw Object.assign(new Error(`NOT_JSON (content-type: ${res.headers?.get?.('content-type') ?? '?'})`), { code: 'NOT_JSON', status: res.status, permanent: true }); }
      }
      last = Object.assign(new Error(`HTTP_${res.status}`), { status: res.status, permanent: res.status >= 400 && res.status < 500 });
    } catch (e) { last = e; }
    if (last.permanent) break;
    await sleep((cfg.retryBaseMs ?? 1000) * 2 ** i);
  }
  throw last;
}

export const journalUrls = (cfg) => {
  const base = String(cfg.url).replace(/\/+$/, '');
  if (cfg.journalUrls?.length) return cfg.journalUrls;
  if (cfg.journalUrl) return [cfg.journalUrl];
  return (cfg.journalPaths ?? ['/data/journal.json']).map((p) => base + p);
};

/**
 * scrapeJournalSite(cfg, { fetchImpl, domScrape }) -> { status, items, diagnostics }
 * status: OK | OK_NO_SETUPS | ZERO_CARDS_UNCONFIRMED | NEEDS_SELECTOR_VERIFICATION | FAILED
 * domScrape(cfg) -> { status, items, diagnostics } dipanggil hanya bila semua URL JSON gagal.
 */
export async function scrapeJournalSite(cfg, { fetchImpl = globalThis.fetch, domScrape = null } = {}) {
  const t0 = Date.now();
  const diag = { httpStatus: null, errors: [], warnings: [], durationMs: 0, source: null, attempts: [], forward: null, meta: null };
  const out = (status, items = []) => { diag.durationMs = Date.now() - t0; return { status, items, diagnostics: diag }; };

  for (const url of journalUrls(cfg)) {
    try {
      const { json, status } = await getJson(url, cfg, fetchImpl);
      diag.httpStatus = status;
      const items = unwrapJournal(json);
      if (!items) { diag.attempts.push({ url, status, error: 'JOURNAL_SHAPE_UNKNOWN' }); continue; }
      diag.attempts.push({ url, status, error: null });
      diag.source = url;
      await addForward(cfg, diag, fetchImpl);
      return out(items.length ? 'OK' : 'OK_NO_SETUPS', items);
    } catch (e) {
      diag.httpStatus = e.status ?? diag.httpStatus;
      diag.attempts.push({ url, status: e.status ?? null, error: String(e.message).slice(0, 160) });
    }
  }
  diag.errors.push(...diag.attempts.map((a) => `JSON ${a.url.replace(/^https?:\/\//, '')}: ${a.error}`));

  if (cfg.domFallback !== false && domScrape) {
    const d = await domScrape(cfg);
    diag.warnings.push('JSON_UNAVAILABLE_USING_DOM_TABLE');
    diag.errors.push(...d.diagnostics.errors);
    diag.warnings.push(...d.diagnostics.warnings);
    diag.meta = d.diagnostics.meta ?? null;
    diag.source = `dom:${cfg.url}`;
    if (d.status === 'OK') { diag.warnings.push(...diag.errors); diag.errors = []; return out('OK', d.items); }   // JSON gagal, sumber tetap terbaca
    if (d.status !== 'FAILED') return out(d.status, d.items);
  }
  return out('FAILED');
}

async function addForward(cfg, diag, fetchImpl) {
  const url = cfg.forwardReportUrl ?? (cfg.forwardReportPath ? String(cfg.url).replace(/\/+$/, '') + cfg.forwardReportPath : null);
  if (!url) return;
  try {
    const { json: f } = await getJson(url, { ...cfg, retries: 1 }, fetchImpl);
    diag.forward = { ready: f.ready ?? null, locked: f.locked ?? null, counts: f.counts ?? null, dibuat: f.dibuat ?? null };
  } catch (e) { diag.warnings.push(`FORWARD_REPORT_UNAVAILABLE: ${String(e.message).slice(0, 100)}`); }
}
