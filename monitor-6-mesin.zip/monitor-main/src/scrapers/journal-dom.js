import { withBrowser, withTimeout } from '../browser/session.js';
import { extractJournalTable } from '../parsers/journal-dom.js';

/** Cadangan berbasis browser: membuka halaman, menunggu tabel Jurnal terisi, lalu membaca barisnya. */
export async function scrapeJournalDom(cfg) {
  const t0 = Date.now();
  const diag = { httpStatus: null, errors: [], warnings: [], durationMs: 0, meta: null };
  const out = (status, items = []) => { diag.durationMs = Date.now() - t0; return { status, items, diagnostics: diag }; };
  try {
    return await withBrowser(async (ctx) => {
      const page = await ctx.newPage();
      try {
        const resp = await page.goto(cfg.url, { waitUntil: 'domcontentloaded', timeout: cfg.gotoTimeoutMs ?? 45000 });
        diag.httpStatus = resp?.status?.() ?? null;
        if (diag.httpStatus >= 400) { diag.errors.push(`DOM_HTTP_${diag.httpStatus}`); return out('FAILED'); }
        // Tabel dirender oleh JS: tunggu sampai ada tabel berheader aset/arah dengan >1 baris (atau habis waktu).
        await page.waitForFunction(() => [...document.querySelectorAll('table')]
          .some((t) => /aset/i.test(t.textContent) && t.querySelectorAll('tr').length > 2), null, { timeout: cfg.tableWaitMs ?? 20000 })
          .catch(() => diag.warnings.push('DOM_TABLE_WAIT_TIMEOUT'));
        const res = await withTimeout(page.evaluate(extractJournalTable), 30000, 'extract-journal');
        diag.meta = res.meta;
        if (!res.meta.found) { diag.errors.push('DOM_JOURNAL_TABLE_NOT_FOUND'); return out('NEEDS_SELECTOR_VERIFICATION'); }
        return out(res.items.length ? 'OK' : 'ZERO_CARDS_UNCONFIRMED', res.items);
      } finally { await page.close().catch(() => {}); }
    });
  } catch (e) {
    diag.errors.push(`DOM_ERROR: ${String(e.message).slice(0, 200)}`);
    return out('FAILED');
  }
}
