import { toWib } from './util/time.js';
import { summarize, groupBy, periodStats, markClusters, compareEngines, agreementMatrix, equityCurve } from './statistics/stats.js';

const view = (s, cl) => ({
  id: s.setupId, engine: s.engine, analysisWib: s.analysisTimeWib, analysisUtc: s.analysisTimeUtc, ticker: s.ticker,
  direction: s.direction, entryType: s.entryType, entry: s.entryPrice, entryRange: s.entryRange, tp: s.takeProfit,
  sl: s.stopLoss, rr: s.riskReward, riskPct: s.riskPercent, reason: s.entryReason, timeframe: s.timeframe,
  originalStatus: s.originalStatus, latestOriginalStatus: s.latestOriginalStatus,
  result: s.evaluation?.result ?? 'PENDING', resultWib: toWib(s.evaluation?.resultTimeUtc), resultTimeSource: s.evaluation?.resultTimeSource ?? null,
  entryWib: toWib(s.evaluation?.entryTimeUtc), r: s.evaluation?.rMultiple ?? null, notes: s.evaluation?.notes ?? [],
  reasonCode: s.evaluation?.reasonCode ?? null, warnings: s.warnings ?? [], clusterId: cl?.clusterId, isPrimary: cl?.isPrimary ?? true,
  analysisTimeSource: s.analysisTimeSource, sourceResult: s.sourceResult ?? null, sourceR: s.sourceR ?? null,
  priceDataError: s.evaluation?.priceDataError ?? null,
});

/** engineList: [{ id, label, url }]. Bila kosong, diturunkan dari setup yang ada. */
export function buildDashboard({ setups, diagnostics, cfg, nowIso, engineList }) {
  const list = engineList?.length ? engineList : [...new Set(setups.map((s) => s.engine))].sort().map((id) => ({ id, label: id, url: null }));
  const ids = list.map((e) => e.id);
  const clusters = markClusters(setups, cfg.cluster);
  const rows = setups.map((s) => view(s, clusters.get(s.setupId)))
    .sort((a, b) => (a.analysisUtc < b.analysisUtc ? 1 : -1));
  const by = (e, primaryOnly) => setups.filter((s) => s.engine === e && (!primaryOnly || clusters.get(s.setupId).isPrimary));
  const copts = { minSample: cfg.minSamplePerEngine, iterations: cfg.bootstrapIterations };

  const engines = {}, comparison = {}, leaderboard = {}, equity = {};
  for (const scope of ['independent', 'all']) {
    const po = scope === 'independent';
    engines[scope] = {}; equity[scope] = {};
    for (const e of ids) {
      const l = by(e, po);
      engines[scope][e] = { summary: summarize(l), byTicker: groupBy(l, (s) => s.ticker), byDirection: groupBy(l, (s) => s.direction),
        byTimeframe: groupBy(l, (s) => s.timeframe), byReason: groupBy(l, (s) => s.entryReason),
        daily: periodStats(l, 'daily'), weekly: periodStats(l, 'weekly'), monthly: periodStats(l, 'monthly') };
      equity[scope][e] = equityCurve(l);
    }
    // Perbandingan berpasangan (A vs B) dengan bootstrap; verdict hanya bila kedua mesin >= minSample.
    const pairwise = [];
    for (let i = 0; i < ids.length; i++) for (let j = 0; j < ids.length; j++) if (i < j)
      pairwise.push({ a: ids[i], b: ids[j], ...compareEngines(by(ids[i], po), by(ids[j], po), copts) });
    const wins = Object.fromEntries(ids.map((e) => [e, 0])), losses = { ...wins };
    for (const p of pairwise) {
      if (p.verdict === 'A_BETTER') { wins[p.a]++; losses[p.b]++; }
      if (p.verdict === 'B_BETTER') { wins[p.b]++; losses[p.a]++; }
    }
    comparison[scope] = { minSample: cfg.minSamplePerEngine, pairwise, significantPairs: pairwise.filter((p) => p.verdict === 'A_BETTER' || p.verdict === 'B_BETTER').length };
    leaderboard[scope] = ids.map((id) => { const m = engines[scope][id].summary;
      return { id, published: m.published, resolved: m.resolved, winRate: m.winRate, expectancyR: m.expectancyR, totalR: m.totalR,
        maxDrawdownR: m.maxDrawdownR, eligible: m.resolved >= cfg.minSamplePerEngine, significantWins: wins[id], significantLosses: losses[id] };
    }).sort((x, y) => (y.expectancyR ?? -Infinity) - (x.expectancyR ?? -Infinity));
  }

  const agreement = agreementMatrix(Object.fromEntries(ids.map((e) => [e, by(e, false)])), cfg.pairWindowMinutes);
  const lastRun = diagnostics.runs.at(-1) ?? null;
  const quality = {
    invalid: rows.filter((r) => r.result === 'INVALID'), ambiguous: rows.filter((r) => r.result === 'AMBIGUOUS'),
    unverified: rows.filter((r) => r.priceDataError),
    withWarnings: rows.filter((r) => r.warnings.length), nearDuplicates: rows.filter((r) => !r.isPrimary),
    conflicts: agreement.pairs.filter((p) => p.relation === 'CONFLICT'),
    sourceDisagreements: rows.filter((r) => ['TP', 'SL'].includes(r.sourceResult) && ['TP', 'SL'].includes(r.result) && r.sourceResult !== r.result),
    unknownAnalysisTime: rows.filter((r) => r.analysisTimeSource === 'unknown_before_tracking'),
  };
  return { generatedAtUtc: nowIso, generatedAtWib: toWib(nowIso), counts: { setups: rows.length },
    engineList: list, engines, leaderboard, comparison, equity,
    agreement: { matrix: agreement.matrix, pairs: agreement.pairs.slice(0, 300) },
    setups: rows, quality, diagnostics: { lastRun, runs: diagnostics.runs.slice(-50) },
    methodology: { source: 'Binance Spot klines', note: 'Hasil teoretis berbasis candle (bukan trading nyata): tanpa fee/slippage, fill saat harga menyentuh level.' } };
}
