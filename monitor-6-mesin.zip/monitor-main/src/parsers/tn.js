import { parseTime } from '../util/time.js';

/*
 * Mesin berformat jurnal Asgra (tnv2, gemini, chatgpt, grok, deepseek, meta). Sumber: <situs>/data/journal.json.
 * Field yang dipakai: id, waktu, t, aset, arah, entry, sl, tp, alasan, hasil, R, h.
 * Field lain (harga_awal, due, engine, fwd, seq, prev, tx, bm, bi, alert, keyakinan)
 * disimpan utuh di rawData dan TIDAK ditafsirkan. Arti bm/bi belum diverifikasi.
 * Entry tercatat "Entry limit" pada kartu DOM /tn/ (24 kemunculan di rendered.html).
 */
export function parseJournalEntry(e, engine = 'tn') {
  const warnings = [];
  const num = (x) => (typeof x === 'number' && Number.isFinite(x) ? x : null);
  const tMs = num(e.t);
  const wMs = parseTime(e.waktu);
  if (tMs != null && wMs != null && Math.abs(tMs - wMs) > 60_000) {
    warnings.push(`TIME_MISMATCH: t=${tMs} waktu=${e.waktu}`);
  }
  return {
    engine,
    ticker: e.aset,
    direction: e.arah,
    entryType: 'limit',
    entryPrice: num(e.entry),
    entryRange: null,
    takeProfit: [num(e.tp)],
    stopLoss: num(e.sl),
    entryReason: e.alasan || null,
    originalStatus: e.hasil || null,
    sourceResult: e.hasil || null,
    sourceR: num(e.R),
    analysisTimeMs: tMs ?? wMs,
    analysisTimeSource: 'source',
    // h = hash rantai per entri (unik). Tidak memakai level harga: BTC SHORT 86620 muncul di dua hari.
    idKey: `${engine}|${e.h ?? [e.waktu, e.aset, e.arah, e.entry, e.sl, e.tp].join('|')}`,
    rawData: e,
    warnings,
  };
}
