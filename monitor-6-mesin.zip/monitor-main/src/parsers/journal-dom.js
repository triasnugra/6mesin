/*
 * Cadangan bila <situs>/data/journal.json tidak bisa diambil: baca tabel "Jurnal" yang dirender halaman.
 * Header tabel Mesin 2 yang terverifikasi (data/discovery lama): waktu, aset, arah, entry, sl, tp, hasil, R, alasan.
 * Jalan di dalam browser (page.evaluate) DAN di test (linkedom): harus mandiri, tanpa variabel luar.
 * Kolom dikenali dari teks header, bukan dari urutan, jadi tahan terhadap kolom tambahan.
 */
export function extractJournalTable(doc = globalThis.document) {
  const clean = (s) => (s == null ? '' : String(s).replace(/\s+/g, ' ').trim());
  const num = (s) => {
    const t = clean(s).replace(/[^\d.,-]/g, '');
    if (!/\d/.test(t)) return null;
    const v = Number(t.includes(',') && !t.includes('.') ? t.replace(',', '.') : t.replace(/,/g, ''));
    return Number.isFinite(v) ? v : null;
  };
  const need = ['aset', 'arah', 'entry', 'sl', 'tp'];
  const tables = [...doc.querySelectorAll('table')];
  for (const t of tables) {
    const rows = [...t.querySelectorAll('tr')];
    const headRow = rows.find((r) => r.querySelector('th')) || rows[0];
    if (!headRow) continue;
    const heads = [...headRow.children].map((c) => clean(c.textContent).toLowerCase());
    if (!need.every((k) => heads.includes(k))) continue;
    const col = (k) => heads.indexOf(k);
    const items = [];
    for (const r of rows) {
      if (r === headRow) continue;
      const cells = [...r.children].map((c) => clean(c.textContent));
      const aset = cells[col('aset')];
      if (cells.length < heads.length || !aset) continue;
      const g = (k) => (col(k) >= 0 ? cells[col(k)] : null);
      items.push({
        waktu: g('waktu'), aset, arah: g('arah'),
        entry: num(g('entry')), sl: num(g('sl')), tp: num(g('tp')),
        hasil: g('hasil') || null, R: g('r') != null && g('r') !== '' ? num(g('r')) : '',
        alasan: g('alasan') || null,
      });
    }
    return { items, meta: { found: true, headers: heads, rowCount: items.length, tables: tables.length } };
  }
  return { items: [], meta: { found: false, headers: [], rowCount: 0, tables: tables.length } };
}
